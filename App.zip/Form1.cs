﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp5
{


public partial class Rigister : Form
    {

        public Rigister()
        {
            InitializeComponent();
        }


        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        //first name
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
           
        }

        //last name
        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        //tel
        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        // register
        private void button1_Click(object sender, EventArgs e)
        {
            // saving file with a data
            //if (textBox1 != "" && textBox2 != "" && textBox3 != "")

            StreamWriter txt = new StreamWriter(@"C:\Users\1896360\Desktop\users.txt");
            txt.Write(" firstname : " + textBox1.Text);
            txt.Write(" last name : " + textBox2.Text);
            txt.Write(" phone : " + textBox3.Text);
            txt.Close();

            

            //   else
            //  {
            //    MessageBox.Show("Please Provide Information!");
            //}
        }

        //delete users
        private void button4_Click(object sender, EventArgs e)
        {

        }

        //clear form
        private void button2_Click(object sender, EventArgs e)
        {
           Controls.Clear();

        }

        //count users
        private void button3_Click(object sender, EventArgs e)
        {

        }

      
    }
}
